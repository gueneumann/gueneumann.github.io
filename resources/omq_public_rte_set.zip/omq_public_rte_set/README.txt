1. File: omq_public_all_th_UNBALANCED.xml
- contains th pairs with id: interactionID_categoryID (1_categoryID -  638_categoryID)
- contains 638 entailment th pairs
- contains 24143 nonentailment th pairs

2. File: omq_public_th_TRAINING_UNBALANCED.xml
- is a subset of omq_public_all_th_UNBALANCED.xml
- contains th pairs with id: 239_categoryID, 321_categoryID - 638_categoryID
- contains: 319 entailment th pairs
- contains: 12103 nonentailment th pairs


3. File: omq_public_th_TEST_UNBALANCED.xml
- is a subset of omq_public_all_th_UNBALANCED.xml
- contains th pairs with id: 1_categoryID - 238_categoryID, 240_categoryID - 320_categoryID
- contains: 319 entailment th pairs
- contains: 12040 nonentailment th pairs

4. File: omq_public_th_TRAINING_BALANCED.xml
- is a subset of omq_public_th_TRAINING_UNBALANCED.xml
- contains: 319 entailment th pairs
- contains: 319 nonentailment th pairs
- for every entailment th pair with id: interaction_X_category_Y there is 
exactly one nonentailment th pair with id: interaction_X_category_Z and
exactly one nonentailment th pair with id: interaction_W_category_Y


5. File: omq_public_th_TEST_BALANCED.xml
- is a subset of omq_public_th_TEST_UNBALANCED.xml
- contains: 319 entailment th pairs
- contains: 319 nonentailment th pairs
- for every entailment th pair with id interaction_X_category_Y there is 
exactly one nonentailment th pair with id: interaction_X_category_Z and
exactly one nonentailment th pair with id: interaction_W_category_Y




